package com.example.gs_energia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
