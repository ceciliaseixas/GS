import 'package:flutter/material.dart';
import 'package:gs_energia/models/device.dart';
import 'package:gs_energia/models/mock_data.dart';
import 'package:intl/intl.dart';
import 'add_device_screen.dart';

class AnalysisScreen extends StatefulWidget {
  const AnalysisScreen({super.key});

  @override
  _AnalysisScreenState createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> {
  final List<Device> _devices = MockData.getDevices();

  void _addDevice(Device device) {
    setState(() {
      _devices.add(device);
    });
  }

  String _getSuggestion(double consumo) {
    if (consumo > 200) {
      return 'Consumo alto! Considere reduzir o uso ou substituir por um dispositivo mais eficiente.';
    } else if (consumo > 100) {
      return 'Consumo moderado. Verifique se o dispositivo está funcionando corretamente.';
    } else {
      return 'Consumo baixo. Dispositivo está funcionando eficientemente.';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Análise de Dispositivos'),
        backgroundColor: Colors.green[700],
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {},
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: _devices.length,
        itemBuilder: (context, index) {
          final device = _devices[index];
          final suggestion = _getSuggestion(device.ultimoConsumo);

          return Card(
            margin: const EdgeInsets.all(10.0),
            elevation: 5,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
            color: Colors.green[100],
            child: ListTile(
              leading: Icon(Icons.devices, color: Colors.green[700]),
              title: Text(
                device.nomeDispositivo,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                'Marca: ${device.marca}\n'
                'Modelo: ${device.modelo}\n'
                'Localização: ${device.localizacao}\n'
                'Último Consumo: ${device.ultimoConsumo} kWh\n'
                'Data de Instalação: ${DateFormat.yMd().format(device.dataInstalacao)}\n'
                '$suggestion',
              ),
              isThreeLine: true,
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).push(MaterialPageRoute(
            builder: (context) => AddDeviceScreen(onDeviceAdded: _addDevice),
          ));
        },
        backgroundColor: Colors.green[700],
        child: const Icon(Icons.add),
      ),
    );
  }
}
