class Device {
  final int id;
  final String nomeDispositivo;
  final String marca;
  final String modelo;
  final DateTime dataInstalacao;
  final String localizacao;
  final double ultimoConsumo;

  Device({
    required this.id,
    required this.nomeDispositivo,
    required this.marca,
    required this.modelo,
    required this.dataInstalacao,
    required this.localizacao,
    required this.ultimoConsumo,
  });
}
